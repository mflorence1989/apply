<?php
/*
Plugin Name: iWebtheme moderna shortcodes
Plugin URI: http://iweb-studio.com
Description: Shortcodes plugin for Moderna theme
Author: iWebStudio
Author URI: http://iweb-studio.com
Version: 1.0.2
License: GNU General Public License version 2.0
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/
global $themeshortcode, $post;
require_once( dirname(__FILE__) . '/inc/load.php' ); 
require_once( dirname(__FILE__) . '/inc/shortcode-button.php');
require_once( dirname(__FILE__) . '/inc/shortcode.php'); 
